create
    definer = root@localhost procedure tests_in_pool(IN i_pool_id varchar(10))
BEGIN
    DROP TABLE IF EXISTS tests_in_pool_result;
    CREATE TABLE tests_in_pool_result(
        test_id varchar(7),
        date_tested DATE,
        testing_site VARCHAR(40),
        test_result VARCHAR(20));

    INSERT INTO tests_in_pool_result
-- Type solution below
	SELECT test_id, appt_date, appt_site, test_status from test where pool_id = i_pool_id;
-- End of solution
END;

