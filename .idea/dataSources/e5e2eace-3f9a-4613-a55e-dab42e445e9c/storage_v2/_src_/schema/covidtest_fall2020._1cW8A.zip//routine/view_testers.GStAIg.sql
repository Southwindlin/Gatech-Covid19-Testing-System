create
    definer = root@localhost procedure view_testers()
BEGIN
    DROP TABLE IF EXISTS view_testers_result;
    CREATE TABLE view_testers_result(

        username VARCHAR(40),
        name VARCHAR(80),
        phone_number VARCHAR(10),
        assigned_sites VARCHAR(255));

    INSERT INTO view_testers_result
-- Type solution below

select testerInfo.username, testerInfo.name, testerInfo.phone_num as phone_number, group_concat(WORKING_AT.Site  order by WORKING_AT.Site) as assigned_sites
from (select emUser.username,phone_num, concat(concat(fname,' '),lname) as name
from SITETESTER join (select *
from employee join user on EMPLOYEE.emp_username = user.username) as emUser on SITETESTER.sitetester_username = emUser.username) as testerInfo left outer join WORKING_AT on testerInfo.username = WORKING_AT.username
group by testerInfo.username;

-- End of solution
END;

