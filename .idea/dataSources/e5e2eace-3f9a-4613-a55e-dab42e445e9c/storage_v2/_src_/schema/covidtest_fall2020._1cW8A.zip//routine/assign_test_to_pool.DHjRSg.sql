create
    definer = root@localhost procedure assign_test_to_pool(IN i_pool_id varchar(10), IN i_test_id varchar(7))
BEGIN
-- Type solution below
	SELECT count(*) 
    INTO @num_in_pool
    FROM test
    WHERE pool_id = i_pool_id;
    
	IF @num_in_pool < 7 AND (SELECT pool_id from test where test_id = i_test_id) is null
    THEN 
		UPDATE test 
        SET pool_id = i_pool_id
        WHERE test_id = i_test_id;
	END IF; 
-- End of solution
END;

