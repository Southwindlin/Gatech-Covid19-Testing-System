create
    definer = root@localhost procedure explore_results(IN i_test_id varchar(7))
BEGIN
    DROP TABLE IF EXISTS explore_results_result;
    CREATE TABLE explore_results_result(
        test_id VARCHAR(7),
        test_date date,
        timeslot time,
        testing_location VARCHAR(40),
        date_processed date,
        pooled_result VARCHAR(40),
        individual_result VARCHAR(40),
        processed_by VARCHAR(80)
    );
    INSERT INTO explore_results_result

    -- Type solution below

	select test_id, appt_date as test_date, appt_time as time_slot,appt_site as testing_location, process_date as date_processed,
	pool_status as pool_result, test_status as individual_result, concat(fname, ' ', lname)as processed_by
	from test t
	join pool p on p.pool_id = t.pool_id
	join user s on s.username = p.processed_by
    where test_id = i_test_id;

    -- End of solution
END;

