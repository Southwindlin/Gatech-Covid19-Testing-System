create
    definer = root@localhost procedure create_pool(IN i_pool_id varchar(10), IN i_test_id varchar(7))
BEGIN
-- Type solution below
	if (select COUNT(*) from pool where pool_id = i_pool_id) = 0
    and (select pool_id from test where test_id = i_test_id) is null 
    and (select COUNT(*) from test where test_id = i_test_id) > 0 
    then
	insert into pool (pool_id, pool_status) values (i_pool_id, 'pending');
	update test set pool_id = i_pool_id
	where test_id = i_test_id;
    end if;
-- End of solution
END;

