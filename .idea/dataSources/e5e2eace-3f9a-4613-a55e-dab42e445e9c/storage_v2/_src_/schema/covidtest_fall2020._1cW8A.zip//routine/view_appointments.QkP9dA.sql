create
    definer = root@localhost procedure view_appointments(IN i_site_name varchar(40), IN i_begin_appt_date date,
                                                         IN i_end_appt_date date, IN i_begin_appt_time time,
                                                         IN i_end_appt_time time, IN i_is_available int)
BEGIN
    DROP TABLE IF EXISTS view_appointments_result;
    CREATE TABLE view_appointments_result(

        appt_date DATE,
        appt_time TIME,
        site_name VARCHAR(40),
        location VARCHAR(40),
        username VARCHAR(40));

    INSERT INTO view_appointments_result
-- Type solution below

select appt_date, appt_time, timeRange.site_name, location, timeRange.username
     from  (select * from (select *  from APPOINTMENT 
     where appt_date >= IFNULL(i_begin_appt_date, appt_date) and appt_date <= IFNULL(i_end_appt_date, appt_date)) as dateRange 
     where appt_time >= IFNULL(i_begin_appt_time, appt_time) and appt_time <= IFNULL(i_end_appt_time, appt_time)) as timeRange join SITE on timeRange.site_name = SITE.site_name
where (CASE
    WHEN i_is_available = 0 THEN timeRange.username is not null
    WHEN i_is_available = 1 THEN timeRange.username is null
    WHEN i_is_available IS NULL THEN (timeRange.username is null) or (timeRange.username is not null)
    END)
and timeRange.site_name = IFNULL(i_site_name, timeRange.site_name);


-- End of solution
END;

