create
    definer = root@localhost procedure daily_results()
BEGIN
	DROP TABLE IF EXISTS daily_results_result;
    CREATE TABLE daily_results_result(
		process_date date,
        num_tests int,
        pos_tests int,
        pos_percent DECIMAL(6,2));
	INSERT INTO daily_results_result
    -- Type solution below

    SELECT p.process_date, count(*), SUM( CASE WHEN test_status = 'positive' THEN 1 ELSE 0 END ) as pos_tests, ROUND(100 * SUM( CASE WHEN test_status = 'positive' THEN 1 ELSE 0 END ) / count(*), 2)
    FROM pool as p JOIN test as t on p.pool_id = t.pool_id WHERE p.process_date IS NOT NULL GROUP BY p.process_date;

    -- End of solution
    END;

