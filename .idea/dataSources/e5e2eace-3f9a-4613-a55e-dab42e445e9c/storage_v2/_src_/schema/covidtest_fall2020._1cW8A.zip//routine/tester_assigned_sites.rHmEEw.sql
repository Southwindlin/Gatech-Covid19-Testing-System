create
    definer = root@localhost procedure tester_assigned_sites(IN i_tester_username varchar(40))
BEGIN
    DROP TABLE IF EXISTS tester_assigned_sites_result;
    CREATE TABLE tester_assigned_sites_result(
        site_name VARCHAR(40));

    INSERT INTO tester_assigned_sites_result
-- Type solution below

    SELECT site from working_at where username = i_tester_username;

-- End of solution
END;

