create
    definer = root@localhost procedure register_student(IN i_username varchar(40), IN i_email varchar(40),
                                                        IN i_fname varchar(40), IN i_lname varchar(40),
                                                        IN i_location varchar(40), IN i_housing_type varchar(20),
                                                        IN i_password varchar(40))
BEGIN

-- Type solution below
INSERT INTO user (username, user_password, email, fname, lname) VALUES (i_username, MD5(i_password),
i_email, i_fname, i_lname);
INSERT INTO student (student_username,housing_type,location) VALUES (i_username,i_housing_type,i_location);

-- End of solution
END;

