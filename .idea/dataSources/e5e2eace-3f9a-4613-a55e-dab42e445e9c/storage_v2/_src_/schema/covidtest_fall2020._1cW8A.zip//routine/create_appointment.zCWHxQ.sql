create
    definer = root@localhost procedure create_appointment(IN i_site_name varchar(40), IN i_date date, IN i_time time)
sp_main: BEGIN
-- Type solution below
    -- First get the tester who is working in this site
      -- get the current tester number who are working on this site
      set @testerNumMax = (select 10* count(distinct sitetester_username) from SITETESTER join WORKING_AT on sitetester_username = WORKING_AT.username 
                        where WORKING_AT.site = i_site_name);

     if (select count(*) from Appointment where site_name = i_site_name and i_date = appt_date) >= @testerNumMax then leave sp_main; end if; -- exceed the max appoinments' limit
     if exists (select * from Appointment where site_name = i_site_name and i_date = appt_date and appt_time = i_time) then leave sp_main; end if; -- repeated appointments
     if not exists (select * from SITE where site_name = i_site_name) then leave sp_main; end if; -- the inserted site doesnt't exsit.
     
     
     insert into Appointment values (null, i_site_name,i_date,i_time);
-- End of solution
END;

