create
    definer = root@localhost procedure tests_processed(IN i_start_date date, IN i_end_date date,
                                                       IN i_test_status varchar(10), IN i_lab_tech_username varchar(40))
BEGIN
    DROP TABLE IF EXISTS tests_processed_result;
    CREATE TABLE tests_processed_result(
        test_id VARCHAR(7),
        pool_id VARCHAR(10),
        test_date date,
        process_date date,
        test_status VARCHAR(10) );
    INSERT INTO tests_processed_result
    -- Type solution below
		-- if null entered for start date, then should return earliest test processed date 
        -- where date_processed is not null 
        
        SELECT test_id, t.pool_id, appt_date AS date_tested, 
				process_date AS date_processed, test_status AS result 
		FROM test t 
        JOIN pool p ON p.pool_id = t.pool_id
        WHERE process_date is not null 
        -- null filtering where a start date is null or an ppointment is greater than or equal to a start date and reverse for end date
			AND (i_start_date is null OR t.appt_date >= i_start_date)
            AND (i_end_date is null OR t.appt_date <= i_end_date)
		-- filtering for specific tester
			AND (i_lab_tech_username is null or p.processed_by = i_lab_tech_username)
		-- filtering for result
			AND (i_test_status is null or test_status = i_test_status);
      
    -- End of solution
    END;

