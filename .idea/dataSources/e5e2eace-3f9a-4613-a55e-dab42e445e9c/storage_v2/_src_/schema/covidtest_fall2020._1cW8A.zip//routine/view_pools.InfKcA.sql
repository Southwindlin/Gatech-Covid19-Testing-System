create
    definer = root@localhost procedure view_pools(IN i_begin_process_date date, IN i_end_process_date date,
                                                  IN i_pool_status varchar(20), IN i_processed_by varchar(40))
BEGIN
    DROP TABLE IF EXISTS view_pools_result;
    CREATE TABLE view_pools_result(
        pool_id VARCHAR(10),
        test_ids VARCHAR(100),
        date_processed DATE,
        processed_by VARCHAR(40),
        pool_status VARCHAR(20));

    INSERT INTO view_pools_result
-- Type solution below
	-- if processed by is null and pool status is null --- not using sp_main, so use IFNULL 
    -- look at conditionals 
    -- look into order by 
    -- give myself parameters I know the answer to and then run with those parameters to see if it matches 
		SELECT p.pool_id, GROUP_CONCAT(test_id) AS test_ids, process_date AS date_processed, 
		processed_by, pool_status
		FROM pool p 
		JOIN test t ON p.pool_id = t.pool_id
		WHERE
			(pool_status = 'pending' and i_end_process_date is null and (i_pool_status is null OR i_pool_status = 'pending')
            OR (process_date >= IFNULL(i_begin_process_date, process_date) and process_date <= IFNULL(i_end_process_date, process_date) and pool_status = IFNULL(i_pool_status, pool_status)))
            AND (IFNULL(p.processed_by,1) = COALESCE(i_processed_by, p.processed_by,1))
        GROUP BY p.pool_id; 
    
-- End of solution
END;

