create
    definer = root@localhost procedure assign_tester(IN i_tester_username varchar(40), IN i_site_name varchar(40))
BEGIN
-- Type solution below
	IF NOT EXISTS (SELECT * FROM working_at where username = i_tester_username and site = i_site_name)
    AND EXISTS (SELECT * FROM sitetester where i_tester_username = sitetester_username)
    AND EXISTS (SELECT * FROM site where site_name = i_site_name) THEN
	INSERT INTO working_at
		(username, site)
    VALUES
		(i_tester_username, i_site_name);
	END IF;

-- End of solution
END;

