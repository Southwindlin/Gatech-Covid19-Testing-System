create
    definer = root@localhost procedure register_employee(IN i_username varchar(40), IN i_email varchar(40),
                                                         IN i_fname varchar(40), IN i_lname varchar(40),
                                                         IN i_phone varchar(10), IN i_labtech tinyint(1),
                                                         IN i_sitetester tinyint(1), IN i_password varchar(40))
BEGIN
-- Type solution below
IF NOT (i_labtech = FALSE and i_sitetester = False) THEN
INSERT INTO user (username, user_password, email, fname, lname) VALUES (i_username, MD5(i_password),
i_email, i_fname, i_lname);
INSERT INTO employee (emp_username, phone_num) VALUES (i_username, i_phone);
IF i_sitetester = True THEN
INSERT INTO sitetester VALUES (i_username);
END IF;
IF i_labtech = True THEN
INSERT INTO labtech VALUES (i_username);
END IF;
END IF;
-- here we can set an alert where both i_sitetester and i_labtech are False
-- End of solution
END;

