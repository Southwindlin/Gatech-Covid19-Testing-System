create
    definer = root@localhost procedure test_sign_up_filter(IN i_username varchar(40), IN i_testing_site varchar(40),
                                                           IN i_start_date date, IN i_end_date date,
                                                           IN i_start_time time, IN i_end_time time)
BEGIN
    DROP TABLE IF EXISTS test_sign_up_filter_result;
    CREATE TABLE test_sign_up_filter_result(
        appt_date date,
        appt_time time,
        street VARCHAR (40),
        city VARCHAR(40),
        state VARCHAR(2),
        zip VARCHAR(5),
        site_name VARCHAR(40));

    

    INSERT INTO test_sign_up_filter_result

    -- Type solution below

	select appt_date,appt_time,street,city,state,zip,a.site_name from appointment a
	join site s using (site_name)
	where username is null
    AND location = (select location from student where student_username = i_username)
	AND (i_testing_site = site_name OR i_testing_site IS NULL)
	AND (appt_date >= i_start_date OR i_start_date IS NULL)
	AND (appt_date <= i_end_date OR i_end_date IS NULL)
	AND (appt_time >= i_start_time OR i_start_time IS NULL)
	AND (appt_time <= i_end_time OR i_end_time IS NULL);

    -- End of solution

END;

