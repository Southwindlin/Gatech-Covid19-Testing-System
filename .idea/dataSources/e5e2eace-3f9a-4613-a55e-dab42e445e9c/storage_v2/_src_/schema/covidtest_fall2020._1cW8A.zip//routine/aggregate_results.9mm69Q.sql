create
    definer = root@localhost procedure aggregate_results(IN i_location varchar(50), IN i_housing varchar(50),
                                                         IN i_testing_site varchar(50), IN i_start_date date,
                                                         IN i_end_date date)
BEGIN
    DROP TABLE IF EXISTS aggregate_results_result;
    CREATE TABLE aggregate_results_result(
        test_status VARCHAR(40),
        num_of_test INT,
        percentage DECIMAL(6,2)
    );
    
	drop table if exists temp;
    create temporary table temp  
    select count(*) from test t join appointment a
	on (a.appt_date=t.appt_date and a.appt_time = t.appt_time and a.site_name =t.appt_site)
	join student s on
	s.student_username = a.username
    join pool p using(pool_id)
    where (i_housing = housing_type or i_housing is null)
    and (i_location = location or i_location is null)
    and (i_testing_site = site_name or i_testing_site is null)
    and (i_start_date <= process_date or i_start_date is null)
    and (i_end_date >= process_date or i_end_date is null);
    
    INSERT INTO aggregate_results_result

    -- Type solution below

    
    
	select test_status,count(test_status) as num_of_test, IFNULL(ROUND(count(test_status) * 100 / (select * from temp),2),0) as percentage 
	from test t join appointment a
	on (a.appt_date=t.appt_date and a.appt_time = t.appt_time and a.site_name =t.appt_site)
	join student s on
	s.student_username = a.username
    join pool p using(pool_id)
    where (i_housing = housing_type or i_housing is null)
    and (i_location = location or i_location is null)
    and (i_testing_site = site_name or i_testing_site is null)
    and (i_start_date <= process_date or i_start_date is null)
    and (i_end_date >= process_date or i_end_date is null)
	group by test_status;

    -- End of solution
END;

