create
    definer = root@localhost procedure test_sign_up(IN i_username varchar(40), IN i_site_name varchar(40),
                                                    IN i_appt_date date, IN i_appt_time time, IN i_test_id varchar(7))
BEGIN
-- Type solution below
	IF i_username not in (
    select distinct username
	from test t join appointment a
	on (a.appt_date=t.appt_date and a.appt_time = t.appt_time and a.site_name =t.appt_site)
	where test_status = 'pending') THEN
	
	IF (select username from appointment
    WHERE site_name = i_site_name
    and appt_date = i_appt_date
    and appt_time = i_appt_time) is null then
	UPDATE appointment SET username = i_username 
    WHERE site_name = i_site_name
    and appt_date = i_appt_date
    and appt_time = i_appt_time;

    INSERT INTO test (test_id,test_status,pool_id,appt_site,appt_date,appt_time) VALUES (i_test_id,'pending',null,i_site_name,i_appt_date,i_appt_time);
	END IF;
	END IF;

-- End of solution
END;

