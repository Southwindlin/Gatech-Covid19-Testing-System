create
    definer = root@localhost procedure unassign_tester(IN i_tester_username varchar(40), IN i_site_name varchar(40))
BEGIN
-- Type solution below
	IF ((SELECT COUNT(*) FROM working_at WHERE site = i_site_name) > 1) then 
	DELETE FROM working_at where username = i_tester_username AND site = i_site_name;
	end if;
-- End of solution
END;

