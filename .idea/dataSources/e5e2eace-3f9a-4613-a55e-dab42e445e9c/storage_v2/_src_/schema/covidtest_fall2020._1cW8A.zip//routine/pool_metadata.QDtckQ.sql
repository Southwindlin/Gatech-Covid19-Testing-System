create
    definer = root@localhost procedure pool_metadata(IN i_pool_id varchar(10))
BEGIN
    DROP TABLE IF EXISTS pool_metadata_result;
    CREATE TABLE pool_metadata_result(
        pool_id VARCHAR(10),
        date_processed DATE,
        pooled_result VARCHAR(20),
        processed_by VARCHAR(100));

    INSERT INTO pool_metadata_result
-- Type solution below

    select POOL.pool_id, POOL.process_date as date_processed, POOL.pool_status as pooled_result, concat(concat(fname,' '),lname) as processed_by
    from POOL left outer join USER on POOL.processed_by = USER.username
    where pool_id = i_pool_id;

-- End of solution
END;

