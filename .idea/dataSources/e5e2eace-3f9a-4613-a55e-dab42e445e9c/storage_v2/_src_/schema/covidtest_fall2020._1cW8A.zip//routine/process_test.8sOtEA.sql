create
    definer = root@localhost procedure process_test(IN i_test_id varchar(7), IN i_test_status varchar(20))
BEGIN
-- Type solution below
	-- Processes a test by updating its status. Assume process_pool has already been called for this test's pool.
    SELECT pool_status
    INTO @curr_status
    FROM POOL
    WHERE pool_id = (select pool_id from test where test_id = i_test_id);
    
	IF
        (((SELECT test_status from test where test_id = i_test_id) = 'pending') AND (i_test_status = 'positive' OR i_test_status = 'negative'))
        AND (@curr_status = 'positive' OR (@curr_status = 'negative' AND i_test_status = 'negative'))
    THEN
		UPDATE test 
		SET test_status = i_test_status
		WHERE test_id = i_test_id;
	END IF;
-- End of solution
END;

