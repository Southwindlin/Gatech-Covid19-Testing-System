create
    definer = root@localhost procedure create_testing_site(IN i_site_name varchar(40), IN i_street varchar(40),
                                                           IN i_city varchar(40), IN i_state char(2), IN i_zip char(5),
                                                           IN i_location varchar(40),
                                                           IN i_first_tester_username varchar(40))
sp_main:BEGIN
-- Type solution below

-- first check whether such user exist
if (select count(*)
from SITETESTER
where sitetester_username = i_first_tester_username) <= 0 then leave sp_main; end if;


insert into covidtest_fall2020.SITE values (i_site_name,i_street,i_city,i_state,i_zip,i_location);
insert into covidtest_fall2020.WORKING_AT values (i_first_tester_username,i_site_name);
-- End of solution
END;

